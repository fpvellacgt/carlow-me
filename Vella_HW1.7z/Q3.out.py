# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 16:50:49 2025

@author: fcvella
"""

"Q3.out"

# main.py for Q3
age = int(input("Please enter your age: "))
with open("q3.out", "w") as file:
    if age < 20:
        file.write("fail")
    elif 20 <= age <= 30:
        file.write("pass")
    else:
        file.write("fail")

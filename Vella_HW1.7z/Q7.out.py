"Q7.out"

pokemon_dict = {}
with open("poke.csv", newline="") as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        pokemon_dict[row[1].lower()] = row[0]

team = []
while len(team) < 6:
    pokemon_name = input("Enter Pokémon name (or 'exit' to finish): ").lower()

    if pokemon_name == 'exit':
        break
    elif pokemon_name in pokemon_dict:
        team.append(pokemon_name.capitalize())
    else:
        print("Pokémon not found!")
# Contingency for if a name is not found. 
with open("q7.out", "w") as file:
    for pokemon in team:
        file.write(f"{pokemon}\n")

# Team building for pokemon. 
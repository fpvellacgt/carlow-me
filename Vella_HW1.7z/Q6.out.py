# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 16:56:38 2025

@author: fcvella
"""

"Q6.out.py"

# main.py for Q6
import csv

pokemon_dict = {}
with open("poke.csv", newline="") as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        pokemon_dict[row[1].lower()] = row[0]  # Store name as key and ID as value

pokemon_name = input("Enter the name of a Pokémon: ").lower()

if pokemon_name in pokemon_dict:
    with open("q6.out", "w") as file:
        file.write(f"ID: {pokemon_dict[pokemon_name]}\nName: {pokemon_name.capitalize()}")
else:
    print("Pokémon not found!")

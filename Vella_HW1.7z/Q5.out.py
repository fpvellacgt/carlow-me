# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 16:53:31 2025

@author: fcvella
"""

"Q5.out"

# main.py for Q5
students = []
while True:
    print("1) Enter user\n2) Exit")
    choice = input("Choose an option: ")

    if choice == '1':
        name = input("Enter student name: ")
        students.append(name)
    elif choice == '2':
        break
    else:
        print("Invalid choice!")

with open("q5.out", "w") as file:
    for student in students:
        file.write(f"{student}\n")

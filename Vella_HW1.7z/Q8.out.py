"Q8.out"

import csv

# Step 1: Read poke.csv to get pokemon name and id
pokemon_dict = {}
with open("poke.csv", newline="") as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        pokemon_dict[row[1].lower()] = row[0]  # pokemon_name -> pokemon_id

# Step 2: Read locations.csv to map pokemon_id to location
locations_dict = {}
with open("locations.csv", newline="") as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        locations_dict[row[0]] = row[1]  # pokemon_id -> location

# Step 3: Initialize team
team = {}

# Step 4: Allow the user to add Pokémon
while len(team) < 6:
    pokemon_name = input("Enter Pokémon name (or 'exit' to finish): ").lower()
    
    if pokemon_name == 'exit':
        break
    
    if pokemon_name in pokemon_dict:
        pokemon_id = pokemon_dict[pokemon_name]
        location = locations_dict.get(pokemon_id, "Unknown")  # Get location of Pokémon
        team[pokemon_name.capitalize()] = location  # Add to team (dictionary)
    else:
        print("Pokémon not found!")

# Step 5: Output the team and locations to q8.out
with open("q8.out", "w") as file:
    for pokemon, location in team.items():
        file.write(f"{pokemon}: {location}\n")

# Bulding off of Q7, we will build teams and end user will find them on a map. 
# End user has the exit function. 
# End user will be notified if a pokemon is not found. 




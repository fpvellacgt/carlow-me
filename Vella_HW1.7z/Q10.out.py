"Q10.out.py"

import random

# Dungeon size
width, height = 4, 2  # 4 squares across, 2 squares deep

# Step 1: Create the dungeon (a 4x2 grid)
dungeon = [['.' for _ in range(width)] for _ in range(height)]

# Step 2: Randomly choose a start position and an exit position
start_position = (random.randint(0, height-1), random.randint(0, width-1))
exit_position = (random.randint(0, height-1), random.randint(0, width-1))

# Ensure the start position and exit are not the same
while start_position == exit_position:
    exit_position = (random.randint(0, height-1), random.randint(0, width-1))

# Step 3: Initialize player position
player_position = start_position
moves = 0

# Function to print the dungeon grid (for debugging or visualization)
def print_dungeon():
    for r in range(height):
        row = ""
        for c in range(width):
            if (r, c) == player_position:
                row += "P "  # 'P' for player
            elif (r, c) == exit_position:
                row += "E "  # 'E' for exit
            else:
                row += ". "  # Empty space
        print(row)
    print()

# Step 4: Game loop
while True:
    print("Current Dungeon:")
    print_dungeon()

    # Step 5: Show available moves
    print(f"Player is at position: {player_position}")
    print("Enter a move direction:")
    print("W - Up")
    print("S - Down")
    print("A - Left")
    print("D - Right")
    print("Q - Exit (quit early)")
    
    move = input("Your move: ").strip().upper()

    if move == "Q":
        # Player decides to exit early
        print(f"You decided to exit early. Total moves: {moves}")
        success = False
        break
    
    # Step 6: Process the move
    if move == "W" and player_position[0] > 0:  # Up
        player_position = (player_position[0] - 1, player_position[1])
    elif move == "S" and player_position[0] < height - 1:  # Down
        player_position = (player_position[0] + 1, player_position[1])
    elif move == "A" and player_position[1] > 0:  # Left
        player_position = (player_position[0], player_position[1] - 1)
    elif move == "D" and player_position[1] < width - 1:  # Right
        player_position = (player_position[0], player_position[1] + 1)
    else:
        print("Invalid move. Try again.")
        continue
# This is for your player's psoition and to move them. 
    # Increment move count
    moves += 1

    # Check if the player has reached the exit
    if player_position == exit_position:
        print(f"Congratulations! You reached the exit in {moves} moves.")
        success = True
        break
 # Exit for player and end of game soon. 
# Step 7: Write the result to a file
with open("dungeon_result.out", "w") as file:
    file.write(f"Success: {success}\n")
    file.write(f"Moves: {moves}\n")
    file.write(f"Player position: {player_position}\n")
    file.write(f"Exit position: {exit_position}\n")

# These ae for your moves in the game (above)
print("Game Over. Result written to 'dungeon_result.out'.")


# This is dungeon crawling! End user will be able to move in all necessary directions. 
# End user will also be able to exit when/if necessary in the game. 
# Eixt is designated with "success = TRUE. "




"Q9.out.py"

import csv

# Step 1: Read poke.csv to get pokemon name and id
pokemon_dict = {}
with open("poke.csv", newline="") as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        pokemon_dict[row[1].lower()] = row[0]  # pokemon_name -> pokemon_id

# Step 2: Read locations.csv to map pokemon_id to location
locations_dict = {}
with open("locations.csv", newline="") as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        locations_dict[row[0]] = row[1]  # pokemon_id -> location

# Step 3: Initialize team
team = {}

# Step 4: Define the menu loop
while True:
    print("\n1) Add Pokemon")
    print("2) List Team")
    print("3) Drop Member")
    print("4) Exit")
    choice = input("Choose an option: ")

    if choice == '1':
        # Add Pokémon to team
        if len(team) < 6:
            pokemon_name = input("Enter Pokémon name: ").lower()
            
            if pokemon_name in pokemon_dict:
                pokemon_id = pokemon_dict[pokemon_name]
                location = locations_dict.get(pokemon_id, "Unknown")
                team[pokemon_name.capitalize()] = location
            else:
                print("Pokémon not found!")
        else:
            print("Team is full. You can't add more than 6 Pokémon.")
    
    elif choice == '2':
        # List current team with IDs
        if team:
            print("\nTeam Members:")
            for idx, pokemon in enumerate(team, start=1):
                print(f"{idx}) {pokemon}")
        else:
            print("Your team is empty.")

    elif choice == '3':
        # Drop a member by ID
        if team:
            print("\nYour current team:")
            for idx, pokemon in enumerate(team, start=1):
                print(f"{idx}) {pokemon}")
            
            try:
                id_to_remove = int(input("Enter the ID of the Pokémon you want to remove: "))
                if 1 <= id_to_remove <= len(team):
                    pokemon_to_remove = list(team.keys())[id_to_remove - 1]
                    del team[pokemon_to_remove]
                    print(f"{pokemon_to_remove} has been removed from your team.")
                else:
                    print("Invalid ID.")
            except ValueError:
                print("Invalid input. Please enter a number.")
        else:
            print("Your team is empty. No members to remove.")

    elif choice == '4':
        # Exit and output team to file
        with open("q9.out", "w") as file:
            for pokemon, location in team.items():
                file.write(f"{pokemon}: {location}\n")
        print("Team data has been written to q9.out.")
        break
    
    else:
        print("Invalid choice. Please select a valid option.")

# This is for a menu for managing your pokemon teams. 
# End user will have the option to drop teams and change team members. 
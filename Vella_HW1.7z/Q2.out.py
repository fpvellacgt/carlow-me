# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 16:45:52 2025

@author: fcvella
"""

"Q2.out"

# main.py for Q2
age = int(input("Please enter your age: "))
with open("q2.out", "w") as file:
    file.write(f"Original age: {age}\n")
    file.write(f"Age in 5 years: {age + 5}")


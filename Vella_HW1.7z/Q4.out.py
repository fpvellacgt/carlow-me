# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 16:52:38 2025

@author: fcvella
"""

"Q4.out"

# main.py for Q4
students = []
while True:
    name = input("Enter student name (or type 'exit' to finish): ")
    if name.lower() == 'exit':
        break
    students.append(name)

with open("q4.out", "w") as file:
    for student in students:
        file.write(f"{student}\n")

# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 16:49:06 2025

@author: fcvella
"""

"Q1.out"

# main.py for Q1
Name = input("Please enter your name: ")
formatted_name = Name.capitalize()
greeting = f"Hello, {formatted_name}"

print(greeting)

with open("q1.out", "w") as file:
    file.write(greeting)

